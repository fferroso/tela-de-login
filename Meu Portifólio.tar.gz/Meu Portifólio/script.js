let links_navbar = document.querySelector("#navbar")

links_navbar.addEventListener('click', function(){
    alert("Página ainda em desenvolvimento, em breve nova atualizações")})



